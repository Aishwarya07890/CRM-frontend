export const shortText = (str) => {
  return str.length >= 3 && str.length <= 100;
};
